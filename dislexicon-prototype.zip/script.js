
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("word-form");
    const wordInput = document.getElementById("word");
    const meaningInput = document.getElementById("meaning");
    const tagInput = document.getElementById("tag");
    const wordsList = document.getElementById("words-list");
    const exportBtn = document.getElementById("export");

    let words = JSON.parse(localStorage.getItem("words")) || [];

    function saveWords() {
        localStorage.setItem("words", JSON.stringify(words));
    }

    function renderWords() {
        wordsList.innerHTML = "";
        words.forEach((w, index) => {
            const card = document.createElement("div");
            card.className = "word-card";
            card.innerHTML = \`
                <strong>\${w.word}</strong>: \${w.meaning} <em>(\${w.tag || "No tag"})</em>
                <button onclick="removeWord(\${index})">Remove</button>
            \`;
            wordsList.appendChild(card);
        });
    }

    form.addEventListener("submit", (e) => {
        e.preventDefault();
        const word = wordInput.value.trim();
        const meaning = meaningInput.value.trim();
        const tag = tagInput.value.trim();
        if (word && meaning) {
            words.push({ word, meaning, tag });
            saveWords();
            renderWords();
            form.reset();
        }
    });

    exportBtn.addEventListener("click", () => {
        const blob = new Blob([JSON.stringify(words, null, 2)], { type: "application/json" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "dislexicon-words.json";
        a.click();
    });

    window.removeWord = (index) => {
        words.splice(index, 1);
        saveWords();
        renderWords();
    };

    renderWords();
});
